//
//  ViewController.swift
//  StackCalculator
//
//  Created by Amalie Marie Pedersen on 30/06/15.
//  Copyright (c) 2015 Jacob Mulvad. All rights reserved.
//

import UIKit
import Darwin

class ViewController: UIViewController {

    
    @IBOutlet weak var display: UILabel!
    @IBOutlet weak var history: UILabel!
    
    var userIsTyping = false
    var alreadyDecimal = false
    var cleared = true
    var operandStack = Array<Double>()
    let π = M_PI
    
    
    @IBAction func appendHistory(sender: UIButton) {
        if cleared {
            history.text = sender.currentTitle!
            cleared = false
        }
        else {
            history.text = history.text! + sender.currentTitle!
        }
    }
    
    @IBAction func clear() {
        display.text = "0"
        history.text = "0"
        userIsTyping = false
        alreadyDecimal = false
        cleared = true
    }
    
    @IBAction func appendDigit(sender: UIButton) {
        let digit = sender.currentTitle!
        checkStringForMultiplePeriods(display.text!)
        
        if digit == "π" {
            display.text = "\(π)"
            userIsTyping = true
        }
        else if digit == "." && alreadyDecimal {
            //don't add the digit (only one period is valid in a decimal number)
        }
        else if userIsTyping {
            display.text = display.text! + digit
        }
        else {
            display.text = digit
            userIsTyping = true
        }
        
        println("digit = \(digit)")
    }
    
    private func checkStringForMultiplePeriods(input: String) {
        var counter = 0
        for character in input {
            println(character)
            if character == "."{
                ++counter
            }
        }
        if counter >= 1 {
            self.alreadyDecimal = true
        }
    }
    
    @IBAction func operate(sender: UIButton) {
        let operation = sender.currentTitle!
        if userIsTyping {
            enter()
        }
        switch operation{
        case "×": performOperation { $0 * $1 }
        case "÷": performOperation { $1 / $0 }
        case "+": performOperation { $0 + $1 }
        case "−": performOperation { $1 - $0 }
        case "sin": performOperation { sin($0) }
        case "cos": performOperation { cos($0) }
        case "√": performOperation { sqrt($0) }
        default:
            break
        }
    }
    
    func performOperation(operation: (Double, Double) -> Double){
        if operandStack.count >= 2 {
            displayValue = operation(operandStack.removeLast(), operandStack.removeLast())
            enter()
        }
    }
    
    private func performOperation(operation: Double -> Double){
        if operandStack.count >= 1 {
            displayValue = operation(operandStack.removeLast())
            enter()
        }
    }
    
    
    
    @IBAction func enter() {
        userIsTyping = false
        alreadyDecimal = false
        operandStack.append(displayValue)
        println("operandStack = \(operandStack)")
    }
    
    var displayValue: Double{
        get{
            return NSNumberFormatter().numberFromString(display.text!)!.doubleValue
        }
        set{
            display.text = "\(newValue)"
            userIsTyping = false
        }
    }
}

